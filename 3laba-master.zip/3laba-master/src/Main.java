import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int[][] x = new int[3][3];
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[i].length; j++) {
                x[i][j] = scan.nextInt();
            }
        }
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[i].length; j++) {
                System.out.print(x[i][j] + " ");
            }
            System.out.println();
        }
        insertionSort(x);
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[i].length; j++) {
                System.out.print(x[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void insertionSort(int[][] x) {
        for (int i = 0; i < x.length; i++) {
            for (int g = 1; g < x[i].length; g++) {
                int temp = x[i][g];
                int j;
                for (j = g; j > 0 && temp < x[i][j - 1]; j--) {
                    x[i][j] = x[i][j - 1];

                }
                x[i][j] = temp;
            }
        }
    }
}